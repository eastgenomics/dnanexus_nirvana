﻿namespace CacheUtils.Genbank
{
    internal enum FeaturesState : byte
    {
        Unknown,
        Cds,
        Exon,
        Gene
    }
}
