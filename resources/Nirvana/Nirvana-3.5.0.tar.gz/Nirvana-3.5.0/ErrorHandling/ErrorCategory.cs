﻿namespace ErrorHandling
{
    public enum ErrorCategory
    {
        UserError,
        NirvanaError,
        TimeOutError,
        InvocationThrottledError
    }
}