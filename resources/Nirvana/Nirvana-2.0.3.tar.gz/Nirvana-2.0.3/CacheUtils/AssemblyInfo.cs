﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UnitTests")]