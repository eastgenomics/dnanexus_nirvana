﻿using System;
using ErrorHandling;

namespace CacheUtils.ExtractTranscripts
{
    public static class ExtractTranscriptMain
    {
        public static ExitCodes Run(string command, string[] args)
        {
            Console.WriteLine("SUCCESS");
            return ExitCodes.Success;
        }
    }
}
