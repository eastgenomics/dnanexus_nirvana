﻿namespace SAUtils.ExtractMiniSa
{
	public static class ConfigurationSettings
	{
		#region members

		// filenames
		public static string CompressedReference;
		public static string InputSuppAnnotPath;
		public static string DataSourceName;

		public static int Begin;
		public static int End;
		public static string MiniSaDirectory;

		#endregion
	}
}
