﻿namespace ExtractMiniXml
{
	public static class ConfigurationSettings
	{
		public static string InputXmlFile;
		public static string RcvId;
		public static string OutputDir;
	}
}