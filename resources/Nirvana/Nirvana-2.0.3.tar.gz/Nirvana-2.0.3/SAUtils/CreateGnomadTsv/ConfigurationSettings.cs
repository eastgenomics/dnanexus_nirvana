﻿namespace SAUtils.CreateGnomadTsv
{
    public static class ConfigurationSettings
    {
        public static string InputDirectory;
        public static string OutputDirectory;
        public static string CompressedReference;
        public static string SequencingDataType;
    }
}