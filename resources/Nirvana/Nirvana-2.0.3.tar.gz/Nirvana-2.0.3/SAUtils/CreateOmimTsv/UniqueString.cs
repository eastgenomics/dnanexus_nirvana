﻿namespace SAUtils.CreateOmimTsv
{
    public sealed class UniqueString
    {
        public string Value;
        public bool HasConflict;
    }
}
