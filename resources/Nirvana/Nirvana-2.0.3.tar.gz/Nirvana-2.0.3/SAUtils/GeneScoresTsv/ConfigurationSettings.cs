﻿namespace SAUtils.GeneScoresTsv
{
    public static class ConfigurationSettings
    {
        public static string InputPath;
        public static string OutputDirectory;
    }
}