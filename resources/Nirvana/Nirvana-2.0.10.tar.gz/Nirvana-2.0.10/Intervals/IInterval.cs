﻿namespace Intervals
{
    public interface IInterval
    {
        int Start { get; }
        int End { get; }
    }
}
